# ✍️ AI Text Summarizer — Beginner Friendly

Paste any text and get **Short / Medium / Long** summaries. Built with **Streamlit** + **OpenAI**.
Works 100% in **GitHub Codespaces** (no installs on your computer).

---

## ✅ What You Need
- A **GitHub account** (free)
- An **OpenAI API key** (create at https://platform.openai.com/ and copy your key).

> Keep your key **private**. Put it in a `.env` file — never commit it to GitHub.

---

## 🚀 Run in GitHub Codespaces (Zero Setup)

1) **Create a repo**  
- Go to https://github.com/new  
- Name it `text-summarizer` (any name is fine)  
- Click **Create repository**

2) **Upload these files**  
- On your repo page, click **“uploading an existing file”**  
- Drag & drop **all files** from this starter into GitHub  
- Click **Commit changes**

3) **Open Codespaces**  
- Back on the repo page → click the green **Code** button → **Create codespace on main**

4) **Create your `.env` file** (stores your API key, not committed)  
- In the left Explorer, right‑click the project → **New File** → name it: `.env`  
- Paste this line (replace with your key):
  ```
  OPENAI_API_KEY=sk-...your-key-here...
  ```
- Save the file

5) **Install and run** (Terminal → New Terminal)  
```bash
pip3 install -r requirements.txt
python3 -m streamlit run app.py
```
- A link like **https://xxxx-8501.app.github.dev** appears → click it to open the app

6) **Use the app**  
- Paste text → click **Summarize**  
- Get three versions: **Short (1–2 sentences)**, **Medium (1 paragraph)**, **Long (3–5 bullets)**  
- Click **Copy** buttons to copy results

---

## 💾 (Optional) Save results back to GitHub
1) In Codespaces, create a folder `outputs/`  
2) Click **Download .md** buttons in the app (or copy/paste) and save into `outputs/`  
3) Open the **Source Control** panel → write a message → **Commit** → **Push**  
4) Open the `.md` files in your repo; they render on GitHub

---

## 🧪 Run on your own computer (Optional)
1) Install **Python 3.10+** from https://www.python.org/downloads/  
2) Open a terminal in this project folder and run:
   ```bash
   pip install -r requirements.txt
   python3 -m streamlit run app.py
   ```
3) Create a `.env` file (same as above) before clicking the local link

---

## 📝 LinkedIn Post (copy‑paste)
> Built a **no-setup AI Text Summarizer** in Streamlit + OpenAI. Paste any text and get **Short / Medium / Long** versions instantly. Next up: **multi-language support** and **export to PDF**. Repo in comments. 🚀

---

## 📜 License
MIT — do anything, just keep the license.