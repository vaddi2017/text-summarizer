
import streamlit as st
from openai import OpenAI
from dotenv import load_dotenv
import os

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")

st.set_page_config(page_title="AI Text Summarizer", page_icon="✍️", layout="wide")
st.title("✍️ AI Text Summarizer")
st.caption("Paste text → get Short / Medium / Long summaries.")

# Sidebar: API key status
with st.sidebar:
    st.subheader("API Key")
    if api_key:
        st.success("OPENAI_API_KEY is set ✅")
    else:
        st.error("Missing OPENAI_API_KEY in your .env file ❌")
        st.info("Create a .env file with: OPENAI_API_KEY=your_key_here")

# Only create client if key exists
client = OpenAI(api_key=api_key) if api_key else None

text = st.text_area("Your text", height=220, placeholder="Paste any article, email, or essay here...")

colA, colB = st.columns([1,1])
with colA:
    tone = st.selectbox("Tone (optional)", ["neutral", "friendly", "formal", "concise"], index=0)
with colB:
    use_bullets = st.checkbox("Use bullets for long summary", value=True)

def summarize(kind: str, content: str) -> str:
    if not client:
        return "⚠️ No API key found. Add OPENAI_API_KEY to your .env and rerun."
    if kind == "short":
        instruction = f"Summarize the text in 1-2 sentences. Keep it {tone}. No preface."
    elif kind == "medium":
        instruction = f"Summarize the text in one concise paragraph. Keep it {tone}. No preface."
    else:
        if use_bullets:
            instruction = f"Summarize the text in 3-5 bullet points. Keep it {tone}. No preface."
        else:
            instruction = f"Summarize the text in 3-4 short paragraphs. Keep it {tone}. No preface."

    prompt = f"{instruction}\n\n---\nTEXT:\n{content}\n---"

    try:
        resp = client.responses.create(model="gpt-4o-mini", input=prompt)
        return resp.output_text.strip()
    except Exception as e:
        return f"❌ Error: {e}"

if st.button("Summarize", type="primary") and text.strip():
    with st.spinner("Thinking..."):
        short = summarize("short", text)
        medium = summarize("medium", text)
        long = summarize("long", text)

    st.subheader("📌 Short")
    st.write(short)

    st.subheader("📌 Medium")
    st.write(medium)

    st.subheader("📌 Long")
    st.write(long)

    md = f"# Summaries\n\n## Short\n{short}\n\n## Medium\n{medium}\n\n## Long\n{long}\n"
    st.download_button("⬇️ Download summaries.md", md, file_name="summaries.md")
else:
    st.info("Paste your text above, then click **Summarize**.")
